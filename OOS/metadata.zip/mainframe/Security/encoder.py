# example: secret = "Something something fragment: 230 more-something"
secret = "".encode()

file_name = ""
file_extension = ".dat"
helper = file_name.encode()

key = os.urandom(16)

def encrypt(data, key):
    return bytes([data[i] ^ key[i % len(key)] for i in range(len(data))])

secret = encrypt(secret, key)
helper = encrypt(helper, key)

secret = base64.b64encode(secret).decode()
helper = base64.b64encode(helper).decode()

file_path = os.path.join(file_name + file_extension)
with open(file_path, "w") as f:
    f.write(f"{secret}\n{helper}")