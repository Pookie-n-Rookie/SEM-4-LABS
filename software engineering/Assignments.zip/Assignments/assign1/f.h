#include<stdio.h>
extern void f1(int x, int y);
extern void f2(int *x, int *y);
